Readme File

This package contains HyperSQL version 2.7.3

HyperSQL Database is a relational database management system and a set of tools
written in Java.
HyperSQL is also known as HSQLDB.

The file "index.html" explains the contents of this distribution and has
links to documentation and support resources.
